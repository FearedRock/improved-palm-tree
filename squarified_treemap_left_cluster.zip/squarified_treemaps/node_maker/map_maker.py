from node_maker import Node, create_tree, print_tree
import squarify

def create_squarified_treemap(root):
    labels = []
    values = []
    parents = []

    def add_node_data(node, parent_index):
        nonlocal labels, values, parents
        index = len(labels)
        labels.append(node.id)
        values.append(node.value)
        parents.append(parent_index)

        for child in node.children:
            add_node_data(child, index)

    add_node_data(root, None)
    return labels, values, parents

def draw_squarified_treemap(labels, values, parents, x, y, width, height):
    fill(200, 200, 200)
    stroke(0)
    strokeWeight(1)
    rect(x, y, width, height)

    if len(labels) == 0:
        return
    
    #Gives orientation of the box
    horizontal = width > height
    children = [[labels[i], values[i]] for i in range(len(labels)) if parents[i] == None]
    layout = squarify.squarify(children, x, y, width, height, horizontal)
    for i, rect in enumerate(layout):
        draw_squarified_treemap(
            labels, values, parents, rect['x'], rect['y'], rect['dx'], rect['dy']
        )
        
parent_list = [[0, 1], [0, 2], [0, 3], [0, 4], [0, 5], [0, 6], [0, 7], [0, 11], [0, 12], [0, 13], [0, 14], [0, 15], [0, 16], [1, 10], [2, 20], [2, 21], [2, 22], [2, 23], [2, 24], [2, 25], [2, 26], [3, 30], [3, 31], [3, 32], [3, 33], [3, 34], [3, 35], [3, 36], [4, 40], [4, 41], [4, 42], [4, 43], [4, 44], [4, 45], [4, 46], [5, 50], [5, 51], [5, 52], [5, 53], [5, 54], [5, 55], [5, 56], [6, 60], [6, 61], [6, 62], [6, 63], [6, 64], [6, 65], [6, 66], [7, 70], [7, 71], [7, 72], [7, 73], [7, 74], [7, 75], [7, 76]]
values_list = [[10, 700], [11, 600], [12, 400], [13, 300], [14, 200], [15, 200], [16, 100], [20, 700], [21, 600], [22, 400], [23, 300], [24, 200], [25, 200], [26, 100], [30, 700], [31, 600], [32, 400], [33, 300], [34, 200], [35, 200], [36, 100], [40, 700], [41, 600], [42, 400], [43, 300], [44, 200], [45, 200], [46, 100], [50, 700], [51, 600], [52, 400], [53, 300], [54, 200], [55, 200], [56, 100], [60, 700], [61, 600], [62, 400], [63, 300], [64, 200], [65, 200], [66, 100], [70, 700], [71, 600], [72, 400], [73, 300], [74, 200], [75, 200], [76, 100]]

def setup():
    size(1200, 800)
    root = create_tree(parents_list, values_list)
    print_tree(root)
    plot_tree(root)

def draw():
    background(255)


    labels, values, parents = create_squarified_treemap(root)
    draw_squarified_treemap(labels, values, parents, 0, 0, width, height)
