def parse(file_name):
    f = open(file_name, "r")
    data = f.readlines()
    f.close()

    num_int = []
    num_list = []
    for count, num in enumerate(data):
        num = num.split(' ')
        mini_list = []
        for non_integers in num:
            non_integers = non_integers.strip('\n')
            if non_integers.isnumeric():
                mini_list.append(int(non_integers))
        num_list.append(mini_list)

    num_values = []
    num_parents = []
    parent_child_list = []

    for count, num in enumerate(num_list):
        #dedicated for creating the values list by using the format of the file
        if count == 0 and len(num) == 1:
            for second_count, values in enumerate(num_list[:num[0] + 1]):
                if second_count == 0:
                    pass
                else:
                    num_values.append(values)

        #if the count is greater than 0, then that means that single number represents the parent child
        #relationships
        elif len(num) == 1:
            for third_count, values in enumerate(num_list[count:]):
                if third_count == 0:
                    pass
                else:
                    num_parents.append(values)

    num_parents = sorted(num_parents, key= lambda x: x[0])
    num_values = sorted(num_values, key= lambda x: x[0])
    return(num_parents, num_values)

def parse2(file_name):
    data = loadStrings(file_name)


    return(data)

def setup():
    data = parse('W1-hierarchy2.shf')
    print(data)
